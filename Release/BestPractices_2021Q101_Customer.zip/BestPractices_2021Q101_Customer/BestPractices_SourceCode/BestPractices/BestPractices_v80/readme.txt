===========================================
Background for Common_Model_v3_file[1-3]:
===========================================
There are three Excel and CSV files that start with Common_Model_v3_file[1-3].  
This allows for multiple sets Logical models to be managed.  Each Project will have its own model.
If you only have one logical model to manage then blank out Columns A-L in Common_Model_v3_file2 and Common_Model_v3_file3.
Do not blank out the formulas in columns M-Z.
Whenever more rows are needed, copy and insert "rows" not columns so the formualas are maintained.

Instructions:
================
1. Modify the Excel Spreadsheet (Common_Model_v3_file1, Common_Model_v3_file2 or Common_Model_v3_file3)

2. Save it in Excel format first

[OPTIONAL]
----------
If you require the ability to read CSV files instead of the Excel files then follow these directions:

3. Save as type ...CSV (Comma Delimited)(*.csv)

4. Click "Yes" to overwrite the corresponding .csv file

5. Click "Yes" to keep the the workbook in the format of .csv -- this is ok.

6. Close the file and Click "Don't Save"

8. Repeat this for the other two files if changes were made to them.

7. Copy the files in this directory to c:\CompositeSoftware\BestPractices

==============================================
Common_Model_v3_Difference_Phys_to_Log.xlsx
==============================================
Use this spreadsheet to identify major differences in the physical to logical mappings.

This file is used to test the differences between the physical and logical names as well as the physical and logical types.
The formulas in the two columns "Diff Name-Physical to Logical" and "Diff Type-Physical to Logical" test for differences.
The column "Diff Type-Physical to Logical" in particular only shows differences for types that do not provide a Composite mapping
from the physical to the logical types.


