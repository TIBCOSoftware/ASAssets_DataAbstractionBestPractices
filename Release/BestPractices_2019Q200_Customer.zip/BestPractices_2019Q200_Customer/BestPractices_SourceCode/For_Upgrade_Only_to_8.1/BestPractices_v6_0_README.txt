
When upgrading projects from Best Practices 6.0 to the current release use this repaired Best Practices 6.0.  
It resolves to /shared/ASAssets/Utilities

	Import BestPractices_v6_0_repaired_ASAssets.car into "Desktop (<user>)" with "overwrite" checked.
	Resulting directory: /shared/BestPractices
	
Data Abstraction Sample (optional):
	The sample has been modified to work with the repaired 6.0 version.
	If desired, import BestPractices_v6_0_DataAbstractionSample60.car into "Desktop (<user>)" with "overwrite" checked.
	Resulting directory: /shared/DataAbstractionSample60