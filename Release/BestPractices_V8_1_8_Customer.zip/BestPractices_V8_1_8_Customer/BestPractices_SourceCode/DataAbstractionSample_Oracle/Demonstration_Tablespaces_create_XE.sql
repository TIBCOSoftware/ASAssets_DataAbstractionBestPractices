SET ECHO OFF

PROMPT 
PROMPT specify base data file location as parameter 1 "D:\oraclexe\DataFiles":
DEFINE location     = &1


create tablespace ts_users
  logging
  datafile '&location/ts_user01.dbf' 
  size 500m 
  autoextend on 
  next 50m
  extent management local;

create tablespace ts_composite_cache
  logging
  datafile '&location/ts_composite_cache01.dbf' 
  size 500m 
  autoextend on 
  next 50m
  extent management local;

 
COMMIT;
  
QUIT;