
When upgrading projects from Best Practices 7.3 to the current release use this repaired Best Practices 7.3.  
It resolves to /shared/ASAssets/Utilities

	Import BestPractices_v7_3_repaired_ASAssets.car into "Desktop (<user>)" with "overwrite" checked.
	Resulting directory: /shared/ASAssets/Utilities/BestPractices_v73
	
Data Abstraction Sample (optional):
	The sample has been modified to work with the repaired 7.3 version.
	If desired, import BestPractices_v7_3_DataAbstractionSample73.car into "Desktop (<user>)" with "overwrite" checked.
	Resulting directory: /shared/DataAbstractionSample73
