rem
rem File: demonstration_data.sql 
rem
rem Created: 9/10/2007 
rem
rem
rem Description: This script creates the Composite Software CIS Server Demo database for Oracle.
rem   
rem NOTES
rem   Run as SYS or SYSTEM with following command line:
rem 
rem	C:> sqlplus system/<sys_passwd> @cmpprv_data.sql <sys_passwd> <new_CISORADEMO_passwd>
rem 
rem   If you are using the Oracle Express Edition, the default service name is "XE"
rem
rem	C:> sqlplus system/<sys_passwd> @cmpprv_data_XE.sql <sys_passwd> <new_CISORADEMO_passwd>
rem sqlplus system/admin @cmpprv_data_XE.sql admin password

SET ECHO OFF

PROMPT 
PROMPT specify password for SYS as parameter 1:
DEFINE pass_sys = &1

PROMPT 
PROMPT specify password for the "CMPPRV" users as parameter 2:
DEFINE pass     = &2

PROMPT

-- The first dot in the spool command below is 
-- the SQL*Plus concatenation character

DEFINE spool_file = cis_privilege_install.log
SPOOL &spool_file

REM =======================================================
REM cleanup section (drop users)
REM =======================================================

DROP USER CMPPRV CASCADE ;

REM =======================================================
REM create user
REM three separate commands, so the create user command 
REM will succeed regardless of the existence of the 
REM DEMO and TEMP tablespaces 
REM =======================================================

REM create/grant CMPPRV
REM =============================
CREATE USER CMPPRV IDENTIFIED BY &pass default tablespace CMPPRV_DATA temporary tablespace temp ;
COMMIT;

GRANT CREATE SESSION, CREATE VIEW, ALTER SESSION, CREATE SEQUENCE TO CMPPRV ;
GRANT CREATE SYNONYM, CREATE DATABASE LINK, RESOURCE TO CMPPRV ;
GRANT UNLIMITED TABLESPACE TO CMPPRV ;
COMMIT;

REM =======================================================
REM grants from sys schema
REM =======================================================

CONNECT sys/&pass_sys@XE AS SYSDBA;
GRANT execute ON sys.dbms_stats TO CMPPRV ;

REM =======================================================
REM create CMPPRV schema objects
REM =======================================================

CONNECT CMPPRV/&pass@XE
ALTER SESSION SET NLS_LANGUAGE=American ;
ALTER SESSION SET NLS_TERRITORY=America ;

COMMIT;
SPOOL OFF

QUIT
