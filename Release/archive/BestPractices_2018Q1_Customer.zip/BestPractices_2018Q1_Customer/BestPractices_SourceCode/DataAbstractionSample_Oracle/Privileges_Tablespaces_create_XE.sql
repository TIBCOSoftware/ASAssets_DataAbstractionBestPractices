SET ECHO OFF

PROMPT 
PROMPT specify base data file location as parameter 1 "D:\oraclexe\DataFiles":
DEFINE location     = &1

create tablespace CMPPRV_DATA
  logging
  datafile '&location/ts_cmpprv_data01.dbf' 
  size 500m 
  autoextend on 
  next 50m
  extent management local;

 
COMMIT;
  
QUIT;