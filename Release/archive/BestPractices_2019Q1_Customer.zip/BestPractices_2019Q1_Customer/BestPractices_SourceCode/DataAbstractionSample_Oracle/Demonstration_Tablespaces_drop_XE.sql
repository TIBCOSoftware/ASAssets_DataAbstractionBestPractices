drop tablespace ts_users INCLUDING CONTENTS;
drop tablespace ts_composite_cache INCLUDING CONTENTS;

COMMIT;
  
QUIT;