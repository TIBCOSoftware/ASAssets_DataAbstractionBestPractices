--A stored procedure to print out a �Hello World� via DBMS_OUTPUT.
CREATE OR REPLACE PROCEDURE procPrintHelloWorld
IS
BEGIN
 
  DBMS_OUTPUT.PUT_LINE('Hello World!');
 
END;
/
-- A stored procedure to accept a single parameter and print out the �Hello World IN parameter� + parameter value via DBMS_OUTPUT.
CREATE OR REPLACE PROCEDURE procOneINParameter(param1 IN VARCHAR2)
IS
BEGIN
 
  DBMS_OUTPUT.PUT_LINE('Hello World IN parameter ' || param1);
 
END;
/
-- A stored procedure to output/assign the �Hello World OUT parameter� value to OUT parameter
CREATE OR REPLACE PROCEDURE procOneOUTParameter(outParam1 OUT VARCHAR2)
IS
BEGIN
 
  outParam1 := 'Hello World OUT parameter';
 
END;
/
-- A stored procedure to accept a INOUT parameter (genericParam), construct the output message and assign back to the same parameter name(genericParam) again.
CREATE OR REPLACE PROCEDURE procOneINOUTParameter(genericParam IN OUT VARCHAR2)
IS
BEGIN
 
  genericParam := 'Hello World INOUT parameter ' || genericParam;
 
END;
/
-- A stored procedure, return a ref cursor and accept a IN parameter.
CREATE OR REPLACE PROCEDURE procCursorExample(
cursorParam OUT SYS_REFCURSOR, customerID IN VARCHAR2)
IS
BEGIN
 
  OPEN cursorParam FOR
  SELECT * FROM CUSTOMERS WHERE CUSTOMER_ID = customerID;
 
END;
/
QUIT;
