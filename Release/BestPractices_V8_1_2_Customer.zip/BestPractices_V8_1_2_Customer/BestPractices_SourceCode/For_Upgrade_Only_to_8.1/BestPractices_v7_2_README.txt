
When upgrading projects from Best Practices 7.2 to the current release use this repaired Best Practices 7.2.  
It resolves to /shared/ASAssets/Utilities

	Import BestPractices_v7_2_repaired_ASAssets.car into "Desktop (<user>)" with "overwrite" checked.
	Resulting directory: /shared/BestPractices_v72
	
Data Abstraction Sample (optional):
	The sample has been modified to work with the repaired 7.2 version.
	If desired, import BestPractices_v7_2_DataAbstractionSample72.car into "Desktop (<user>)" with "overwrite" checked.
	Resulting directory: /shared/DataAbstractionSample72