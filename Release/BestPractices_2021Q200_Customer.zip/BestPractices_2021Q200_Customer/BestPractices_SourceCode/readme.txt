
PATCH:
For releases prior to 2020Q201, 
	Import "patch_backupAllDatasources.car" to allow backing up all data sources prior to importing the upgraded "BestPractices_YYYYQnnn.car"
	
UPGRADE:
To upgrade, import the latest "BestPractices_YYYYQnnn.car"
Copy the datasources back to their original location
